import React, { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useBlueskyAuth } from "@bluesky/auth";
import { fetchBlueskyFeed, postToBluesky } from "@bluesky/api";
import dynamic from "next/dynamic";

const Editor = dynamic(() => import("react-quill"), { ssr: false });
import "react-quill/dist/quill.snow.css";

export default function SocialMediaApp() {
  const { login, logout, user } = useBlueskyAuth();
  const [post, setPost] = useState("");
  const [feed, setFeed] = useState([]);

  useEffect(() => {
    if (user) {
      fetchBlueskyFeed()
        .then((data) => setFeed(data))
        .catch((error) => console.error("Error fetching feed:", error));
    }
  }, [user]);

  const handlePost = async () => {
    if (post.trim()) {
      try {
        await postToBluesky(post);
        setPost("");
        fetchBlueskyFeed()
          .then((data) => setFeed(data))
          .catch((error) => console.error("Error fetching feed:", error));
      } catch (error) {
        console.error("Error posting:", error);
      }
    }
  };

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Group Social Media</h1>
      {user ? (
        <>
          <Card>
            <CardContent>
              <Editor value={post} onChange={setPost} placeholder="What's on your mind?" />
              <Button onClick={handlePost} className="mt-2">Post</Button>
              <Button onClick={logout} className="mt-2 ml-2">Logout</Button>
            </CardContent>
          </Card>
          <div className="mt-6">
            {feed.map((item, index) => (
              <Card key={index} className="mt-2">
                <CardContent>
                  <div dangerouslySetInnerHTML={{ __html: item.content }} />
                  <span className="text-gray-500 text-sm">{item.author}</span>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      ) : (
        <Button onClick={login}>Login with Bluesky</Button>
      )}
    </div>
  );
}