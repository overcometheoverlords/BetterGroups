import SocialMediaApp from "../components/SocialMediaApp";

export default function Home() {
  return <SocialMediaApp />;
}